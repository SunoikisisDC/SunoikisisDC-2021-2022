Originally published: 2022-03-01
This version: 1

*******************

GENERAL INFORMATION

*******************

1. TITLE

Example dataset accompanying Session 8, "GIS," Sunoikisis Digital Cultural Heritage, Spring 2022

2. AUTHOR INFORMATION

Dr. Rebecca M. Seifried
University of Massachusetts Amherst
Amherst, MA, USA
rseifried@umass.edu
rmseifried@gmail.com (permanent)

3. DESCRIPTION

Dataset for visualizing different kinds of attribute data in GIS software. The data are a processed version of the Pyla-Koutsopetria Archaeological Project survey data available on Open Context (Caraher et al. 2013), provided in CSV format. The exercise and a link to the video tutorial can be found at: https://github.com/SunoikisisDC/SunoikisisDC-2021-2022/wiki/8-GIS

4. LICENSES

This data package is made available under the Creative Commons Attribution 4.0 International License: https://creativecommons.org/licenses/by/4.0/legalcode.


**********************

DATA AND FILE OVERVIEW

**********************

1. FILE LIST

A. PKAP_finds_20220301.csv

Processed version of the data tables from the Pyla-Koutsopetria Archaeological Project I: Pedestrian Survey (Caraher et al. 2013). The table contains one row per survey unit, with selected attribute data about survey conditions (e.g. vegetation height and visibility), and summed totals of the processed finds by total quantity, material type, and chronological period.


**********

REFERENCES

**********

Caraher, William R., R. Scott Moore, David K. Pettegrew. "Pyla-Koutsopetria Archaeological Project I: Pedestrian Survey". (2013) William R. Caraher, R. Scott Moore, David K. Pettegrew (Eds.) . Released: 2013-10-25. Open Context. <http://opencontext.org/projects/3F6DCD13-A476-488E-ED10-47D25513FCB2> DOI: https://doi.org/10.6078/M7B56GNS ARK (Archive): https://n2t.net/ark:/28722/k2dj59f9n

