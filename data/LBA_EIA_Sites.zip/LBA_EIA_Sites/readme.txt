Originally published: 2022-03-03
This version: 1

*******************

GENERAL INFORMATION

*******************

1. TITLE

LH IIIA – Geometric archaeological sites in central and southern Greece: a dataset compiled from K. Syriopoulos, Οι Προϊστορική Κατοίκησεις της Ελλάδος, Athens, 1994-1995.

2. AUTHOR INFORMATION
Dr. Sarah C. Murray
sarahclausewitzmurray@gmail.com

3. DESCRIPTION

This data is mainly compiled from the material presented in Konstantinos Syriopoulos's multivolume compendia of prehistoric archaeological sites from the Palaeolithic to the Geometric periods in Greece. It is comprised of point data that approximately maps the sites catalogued in Syriopoulos's text. It was created using QGIS. The data for LH IIIA is partial and data from the regions of Macedonia and Thrace is absent.

4. LICENSES
This data package is being shared for educational and training purposes by its compiler.

**********************

DATA AND FILE OVERVIEW

**********************

1. FILE LIST
A. LBA-EIA-Sites-scm-2018_20220302.csv

CSV file of the data.

In addition to lat/long coordinates for sites, the data includes a number of attribute fields:

Category: the period (in Aegean ceramic terms – LB IIIA, IIIB, IIIC, Protogeometric, Geometric) which concerns the data in the entry – since the data for each site may be different according to period (e.g., a site with excavated IIIA deposits but Geometric material known only from the surface), there are multiple entries for multi-period sites. This format follows the format in which Syriopoulos structured the data in his books.

Site name: Name of the site

Microregion: Modern Greek nome in which the site is located

Macroregion: Wider region

Period: All periods represented at the site (in Aegean ceramic terms – LB IIIA, IIIB, IIIC, Protogeometric, Geometric)

Type: General nature of the finds (cemetery, settlement, isolated tomb, stray artifacts)

Ex-History: Nature/extent of exploration of the site (e.g., survey or excavation, intensive/extensive, rescue/research, etc.)

Discovery: Date of first publication

Source: Source of first publication

Language: Language of first publication

Agent: Institutional agency behind the discovery exploration of the site

Chr-Cert: Certainty of the chronology (Certain, Uncertain, or Probable). 

Grade: A "grade" is also included – this tracks the extent of complex information about ancient society that can be extracted from the remains at the site based on how much has been explored/published – 1 is the maximum (quite a lot of complex information), 2 indicates some information, 3 indicates that all we can say from the remains is that something definitely occurred at the site during a given period, while 4 is the minimum, indicating that the site does not even provide certain information of any activity for a given period.

**********

REFERENCES
**********
K. Syriopoulos, Οι Προϊστορική Κατοίκησεις της Ελλάδος και η Γένεσις του Ελληνικού Έθνους, 2 volumes, Library of the Archaeological Society at Athens no. 139, Athens, 1994-1995.

